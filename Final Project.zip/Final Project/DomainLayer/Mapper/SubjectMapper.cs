﻿using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Mapper
{
    public class SubjectMapper : IEntityTypeConfiguration<Subject>
    {
        public void Configure(EntityTypeBuilder<Subject> builder)
        {
            builder.HasKey(x => x.Id)
                .HasName("pk_SubjectID");

            builder.Property(x => x.Id)
               .ValueGeneratedOnAdd()
               .HasColumnName("SubjectID")
               .HasColumnType("uniqueidentifier");

            builder.Property(x => x.Subject_Name)
               .HasColumnName("Subject_Name")
               .HasColumnType("Nvarchar(150)")
               .IsRequired();



        }
    }
}
