﻿using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Mapper
{
    public  class TeacherMapper: IEntityTypeConfiguration<TeacherTable>
    {      

        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<TeacherTable> builder)
        {
            builder.HasKey(x => x.Id)
                .HasName("pk_TeacherID");

            builder.Property(x => x.Id)
               .ValueGeneratedOnAdd()
               .HasColumnName("TeacherID")
               .HasColumnType("uniqueidentifier");
            builder.Property(x => x.Teacher_Name)
               .ValueGeneratedOnAdd()
               .HasColumnName("Teacher_Name")
               .HasColumnType("Nvarchar(20)");





        }
    }
}
