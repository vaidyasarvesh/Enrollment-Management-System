﻿using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Mapper
{
    public class CourseMapper : IEntityTypeConfiguration<Course>
    {
        public void Configure(EntityTypeBuilder<Course> builder)
        {
            builder.HasKey(x => x.Id)
                .HasName("pk_CourseID");

            builder.Property(x => x.Id)
               .ValueGeneratedOnAdd()
               .HasColumnName("CourseID")
               .HasColumnType("uniqueidentifier");

            builder.Property(x => x.Course_Name)
               .HasColumnName("Course_Name")
               .HasColumnType("Nvarchar(30)")
               .IsRequired();

            builder.Property(x => x.Course_Fees)
               .HasColumnName("Course_Fees")
               .HasColumnType("Decimal")
               .IsRequired(); 

            builder.Property(x => x.Course_Description)
               .HasColumnName("Course_Description")
               .HasColumnType("Nvarchar(30)")
               .IsRequired();



           
        }
    }
}
