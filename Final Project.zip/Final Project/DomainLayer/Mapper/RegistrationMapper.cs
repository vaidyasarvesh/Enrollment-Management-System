﻿using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Mapper
{
    public class RegistrationMapper : IEntityTypeConfiguration<Registration>
    {
        public void Configure(EntityTypeBuilder<Registration> builder)
        {
            builder.HasKey(x => x.Id)
                .HasName("Pk_RegistrationID");


            builder.Property(x => x.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("RegistrationID")
                .HasColumnType("uniqueidentifier");


            builder.Property(x => x.First_Name)
                .HasColumnName("FirstName")
                .HasColumnType("Nvarchar(50)")
                .IsRequired();

            builder.Property(x => x.Last_Name)
                .HasColumnName("LastName")
                .HasColumnType("Nvarchar(50)")
                .IsRequired();

            builder.Property(x => x.Email)
                .HasColumnName("Email")
                .HasColumnType("Nvarchar(100)")
                .IsRequired();

            builder.Property(x => x.Password)
                .HasColumnName("Password")
                .HasColumnType("Nvarchar(50)")
                .IsRequired();

            builder.Property(x => x.Gender)
                .HasColumnName("Gender")
                .HasColumnType("Nvarchar(10)")
                .IsRequired();

            builder.Property(x => x.DOB)
                .HasColumnName("DOB")
                .HasColumnType("DateTime")
                .IsRequired();


            builder.Property(x => x.MobileNo)
                .HasColumnName("MobileNo")
                .HasColumnType("Nvarchar(15)")
                .IsRequired();


            builder.Property(x => x.PinCode)
                .HasColumnName("PinCode")
                .HasColumnType("int")
                .IsRequired();


            builder.Property(x => x.Address)
               .HasColumnName("Address")
               .HasColumnType("Nvarchar(100)")
               .IsRequired();

            builder.Property(x => x.Photo)
                .HasColumnName("Photo")
                .HasColumnType("Nvarchar(200)")
                .IsRequired();


        }

    }

}


