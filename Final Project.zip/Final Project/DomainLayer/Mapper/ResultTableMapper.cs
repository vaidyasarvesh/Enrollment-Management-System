﻿using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Mapper
{
    public  class ResultTableMapper:IEntityTypeConfiguration<ResultTable>
    {      

        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<ResultTable> builder)
        {
            builder.HasKey(x => x.Id)
               .HasName("pk_ResultID");

            builder.Property(x => x.Id)
                   .ValueGeneratedOnAdd()
                   .HasColumnName("ResultID")
                   .HasColumnType("uniqueidentifier");

            builder.Property(x => x.Student_Result)
                  .ValueGeneratedOnAdd()
                  .HasColumnName("Student_Result")
                  .HasColumnType("Nvarchar(20)");
        }
    }
}
