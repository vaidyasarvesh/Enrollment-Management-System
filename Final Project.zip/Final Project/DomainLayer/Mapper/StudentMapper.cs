﻿using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Mapper
{
    public class StudentMapper : IEntityTypeConfiguration<Students>
    {
        public void Configure(EntityTypeBuilder<Students> builder)
        {
            builder.HasKey(x => x.Id)
               .HasName("pk_StudentID");

            builder.Property(x => x.Id)
                   .ValueGeneratedOnAdd()
                   .HasColumnName("StudentID")
                   .HasColumnType("uniqueidentifier");


            builder.Property(x => x.Student_FirstName)
                    .HasColumnName("Student_FirstName")
                    .HasColumnType("Nvarchar(50)")
                    .IsRequired();

            builder.Property(x => x.Student_LastName)
                    .HasColumnName("Student_LastName")
                    .HasColumnType("Nvarchar(50)")
                    .IsRequired();

            builder.Property(x => x.Student_DOB)
                    .HasColumnName("Student_DOB")
                    .HasColumnType("DateTime")
                    .IsRequired();

            builder.Property(x => x.StudentCourse_Name)
                    .HasColumnName("StudentCourse_Name")
                    .HasColumnType("Nvarchar(50)")
                    .IsRequired();

            
        }
    }
}
