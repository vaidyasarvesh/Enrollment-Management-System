﻿using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Mapper
{
    public class CoursesAndSubjectsJunctionMapper : IEntityTypeConfiguration<CoursesAndSubjectJunction>
    {
        public void Configure(EntityTypeBuilder<CoursesAndSubjectJunction> builder)
        {
          


            builder
                .HasKey(t => new { t.CoursesJunID, t.SubjectJunID });
            builder
                .HasOne(x => x.CourseJun)
                .WithMany(u => u.SubjectList)
                .HasForeignKey(x => x.CoursesJunID);

            builder
                .HasOne(x => x.SubjectJun)
                .WithMany(u => u.CourseList)
                .HasForeignKey(x => x.SubjectJunID);


        }
    }
}
