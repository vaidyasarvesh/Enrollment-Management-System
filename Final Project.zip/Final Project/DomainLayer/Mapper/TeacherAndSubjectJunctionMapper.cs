﻿using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Mapper
{
    public class TeacherAndSubjectJunctionMapper : IEntityTypeConfiguration<TeacherAndSubjectJunction>
    {
       
        public void Configure(EntityTypeBuilder<TeacherAndSubjectJunction> builder)
        {
            builder
                 .HasKey(t => new { t.TeacherJunID, t.SubjectJunID });
            builder
                .HasOne(x => x.TeacherJun)
                .WithMany(u => u.SubjectList)
                .HasForeignKey(x => x.TeacherJunID);


            builder
               .HasOne(x => x.SubjectJun)
               .WithMany(u => u.TeacherList)
               .HasForeignKey(x => x.SubjectJunID);
        }
    }
}

