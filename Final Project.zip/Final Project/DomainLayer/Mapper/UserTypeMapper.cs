﻿using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Mapper
{
    public class UserTypeMapper : IEntityTypeConfiguration<UserType>
    {
        public void Configure(EntityTypeBuilder<UserType> builder)
        {
            builder.HasKey(x => x.Id)
               .HasName("Pk_UserTypeID");

            builder.Property(x => x.Id)
               .ValueGeneratedOnAdd()
               .HasColumnName("UserTypeID")
               .HasColumnType("uniqueidentifier");

            builder.Property(x => x.UserTypeName)
               .HasColumnName("UserTypeName")
               .HasColumnType("Nvarchar(50)")
               .IsRequired();





            //FK.
            //builder.HasOne(x => x.Registration)
            //    .WithMany(u => u.UserType)
            //    .HasForeignKey(x => x.Id);

        }
    }
}
