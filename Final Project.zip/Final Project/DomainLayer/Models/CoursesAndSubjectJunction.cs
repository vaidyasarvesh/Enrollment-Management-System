﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public class CoursesAndSubjectJunction
    {

        #region ===CoursesID And SubjectsID  Reference.===

        public Guid CoursesJunID { get; set; }
        public Course CourseJun { get; set; }


        public Guid SubjectJunID { get; set; }
        public Subject SubjectJun { get; set; }

        #endregion


    }
}
