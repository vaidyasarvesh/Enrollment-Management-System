﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public  class TeacherTable:BaseEntity
    {

        #region ===Teacher table fields.===

             public String Teacher_Name { get; set; }

        #endregion

        #region ===For foregin key TeacherAndSubjectJunction to subject ===

        [JsonIgnore]
        public List<TeacherAndSubjectJunction> SubjectList { get; set; }

        #endregion

        
    }
}
