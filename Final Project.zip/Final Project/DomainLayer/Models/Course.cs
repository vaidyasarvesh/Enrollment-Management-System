﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public  class Course:BaseEntity
    {
        #region ===Course Table Fields.===

        public string Course_Name { get; set; }
        public decimal Course_Fees { get; set; }
        public string Course_Description { get; set; }

        #endregion


        #region ===For foreign Key===
        [JsonIgnore]
        public List<CoursesAndSubjectJunction> SubjectList { get; set; }

        #endregion








    }
}
