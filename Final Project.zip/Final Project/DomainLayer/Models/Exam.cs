﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public  class Exam:BaseEntity
    {
        #region ===Exam Table Field===

        public DateTime Exam_Date { get; set; }

        #endregion

        #region ===ForeignKey ===

        //StudentID come to student table.
        [ForeignKey("Students")]
        public Guid? StudentID { get; set; }
        public Students Students { get; set; }



        //CourseID comes to course Table.
        [ForeignKey("Course")]
        public Guid? CourseID { get; set; }
        public Course Course { get; set; }



        //SubjectID comes to course Table.
        [ForeignKey("Subject")]
        public Guid? SubjectID { get; set; }
        public Subject Subject { get; set; }

        #endregion


    }
}
