﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public class Registration  :BaseEntity
    {
        #region ===Registration table fields.===

        [Required(ErrorMessage = "Please Enter UserId")]
        [RegularExpression(@"(?:\s|^)#[A-Za-z0-9]+(?:\s|$)", ErrorMessage = "UserID start with # and Only Number and character are allowed eg(#User1001)")]
        [StringLength(10)]
        public string UserID{ get; set; }

        [Required(ErrorMessage = "Please Enter FirstName")]
        [StringLength(100)]
        public string First_Name { get; set; }

        [Required(ErrorMessage = "Please Enter LastName")]
        [StringLength(100)]
        public string Last_Name { get; set; }

        [Required(ErrorMessage = "Please Enter UserTypeName")]
        [StringLength(100)]
        public string UserTypeName { get; set; }

        [RegularExpression(@"^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", ErrorMessage = "Enter Valid Email")]
        [Required(ErrorMessage = "Please Enter Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(50)]
        public string Password { get; set; }
        public string Gender { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }
        public string MobileNo { get; set; }
       public int PinCode { get; set; }

        public string Address { get; set; } 
        public string Photo { get; set; }

        #endregion



        #region ===foreign Key(Relation) with UserType===

        //[ForeignKey("Students")]
        //public Guid StudentID { get; set; }
        //public Students Students { get; set; }



        [ForeignKey("UserType")]
        public Guid? UserTypeID { get; set; }

        [JsonIgnore]
        public UserType UserType { get; set; }


        #endregion


        [JsonIgnore]
        public virtual List<Students> Students{ get; set; }


    }
}
