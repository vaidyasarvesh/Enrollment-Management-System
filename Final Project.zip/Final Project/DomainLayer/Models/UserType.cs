﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public  class UserType : BaseEntity
    {

        #region ===User Type Fields.===

        [Required(ErrorMessage="User Type is required")]
        [StringLength(10)]
            public string UserTypeName { get; set; }

        #endregion

        [JsonIgnore]
        public virtual List<Registration> Registration { get; set; }



        




        

    }
}
