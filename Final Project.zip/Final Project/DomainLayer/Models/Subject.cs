﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public  class Subject:BaseEntity
    {

        #region ===Subject table fields===

        public string Subject_Name { get; set; }

        #endregion



        #region ===Foreign key CoursesAndSubjectsjunction to course ,CoursesAndSubjectsjunction to teacher ===

        //For table.(FK)
        [JsonIgnore]
        public List<CoursesAndSubjectJunction> CourseList { get; set; }
        [JsonIgnore]
        public List<TeacherAndSubjectJunction> TeacherList { get; set; }


        #endregion








    }
}
