﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public  class ResultTable:BaseEntity
    {
        #region ===Result Table Fileds ===

        public string Student_Result { get; set; }

        #endregion

        #region ===Foreign Key ExamID,StudentID===

        [ForeignKey("Exam")]
        public Guid? ExamID { get; set; }
        [JsonIgnore]
        public Exam Exam { get; set; }


        [ForeignKey("Students")]
        public Guid? StudentID { get; set; }
        [JsonIgnore]
        public Students Students { get; set; }

        #endregion



       

       

    }
}
