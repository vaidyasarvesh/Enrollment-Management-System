﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public  class Students :BaseEntity
    {
        //#region ===ForeignKey RegistrationID===

        [ForeignKey("Registration")]
        public Guid? RegistrationID { get; set; }
        [JsonIgnore]
        public Registration Registration { get; set; }

        //#endregion


        #region ===Student table fields.===

      
        public string Student_FirstName { get; set; }
        public string Student_LastName { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public DateTime Student_DOB { get; set; }
        public string StudentCourse_Name { get; set; }


        #endregion
     

    }
}
