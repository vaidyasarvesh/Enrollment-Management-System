﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public  class TeacherAndSubjectJunction
    {

        #region ===TeacherID, subjectID Reference for TeacherAndSubjectJunction ===

        public Guid TeacherJunID { get; set; }
        [JsonIgnore]
        public TeacherTable TeacherJun { get; set; }

         public Guid SubjectJunID { get; set; }
        [JsonIgnore]
        public Subject SubjectJun { get; set; }

        #endregion




    }
}
