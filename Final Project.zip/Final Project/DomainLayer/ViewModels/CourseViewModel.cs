﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.ViewModels
{
    public  class CourseViewModel
    {
        public Guid Id { get; set; }

        public string Course_Name { get;set; }
        public decimal Course_Fees { get;set;}
        public string Course_Description { get;set; }
    }

    public class CourseInsertModel
    {
        [Required(ErrorMessage = "Course is required")]
        [StringLength(20)]
        public string Course_Name { get; set; }
        public decimal Course_Fees { get; set; }
        public string Course_Description { get; set; }
    }
    public class CourseUpdateModel : CourseInsertModel
    {
        public Guid Id { get; set; }
    }
 }
