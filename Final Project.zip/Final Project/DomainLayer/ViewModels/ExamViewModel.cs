﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.ViewModels
{
    public  class ExamViewModel
    {
        public Guid Id { get; set; }
        public DateTime Exam_Date { get; set; }

    }
    public class ExamInsertModel
    {
        //[Required(ErrorMessage = "Exam Type  is required")]
        //[StringLength(10)]
      
        public DateTime Exam_Date { get; set; }
    }
    public class ExamUpdateModel: ExamInsertModel
    {
        //[Required(ErrorMessage = "Exam Type  is required")]
        //[StringLength(10)]
        public  Guid Id  { get; set; }
    }
}
