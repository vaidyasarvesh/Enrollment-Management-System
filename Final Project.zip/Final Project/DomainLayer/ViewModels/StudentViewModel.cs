﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.ViewModels
{
    public  class StudentViewModel
    {
        public Guid Id { get; set; }

        
        public string Student_FirstName { get; set; }
        public string Student_LastName { get; set; }
        public DateTime Student_DOB { get; set; }
        public string StudentCourse_Name { get; set; }
    }
    public class StudentInsertModel
    {

       
        [Required(ErrorMessage = "First Name is required")]
        [StringLength(10)]
        public string Student_FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required")]
        [StringLength(10)]
        public string Student_LastName { get; set; }
        public DateTime Student_DOB { get; set; }
        public string StudentCourse_Name { get; set; }
    }
    public class StudentUpdateModel : StudentInsertModel
    {
        [Required(ErrorMessage = "Id is neccessory for updation")]
        public Guid Id { get; set; }
    }
}
