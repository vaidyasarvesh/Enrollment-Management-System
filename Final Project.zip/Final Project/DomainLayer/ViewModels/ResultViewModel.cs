﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.ViewModels
{
    public  class ResultViewModel
    {
        public Guid Id { get; set; }
        public string Student_Result { get; set; }
    }
    public class ResultInsertModel
    {
        //[Required(ErrorMessage = "User Type is required")]
        //[StringLength(10)]
        public string Student_Result { get; set; }
    }
    public class ResultUpdateModel : ResultInsertModel
    {
        //[Required(ErrorMessage = "Id is neccessory for updation")]
        public Guid Id { get; set; }

    }
}
