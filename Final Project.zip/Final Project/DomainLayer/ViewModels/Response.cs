﻿namespace DomainLayer.ViewModels
{
    public class Response<T>
    {
        public int Status { get; set; }
        public string Message { get; set; }
    }
}
