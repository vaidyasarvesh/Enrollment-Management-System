﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.ViewModels
{
    public class RegistrationViewModel
    {

         public Guid Id { get; set; }
        public string UserID { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }

        public string UserTypeName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Gender { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public string DOB { get; set; }

        public string MobileNo { get; set; }
        public int PinCode { get; set; }

        public string Address { get; set; }

        public string Photo { get; set; }
        public List<UserTypeModel> UserType { get; set; } = new List<UserTypeModel>();
    }


    public class UserInsertModel
    {
        [Required(ErrorMessage = "Please Enter UserId")]
        [RegularExpression(@"(?:\s|^)#[A-Za-z0-9]+(?:\s|$)", ErrorMessage = "UserID start with # and Only Number and character are allowed eg(#User1001)")]
        [StringLength(10)]
        public string UserID { get; set; }

        [Required(ErrorMessage = "Please Enter UserName")]
        [StringLength(100)]
        public string First_Name { get; set; }


        [Required(ErrorMessage = "Please Enter Last_Name")]
        [StringLength(100)]
        public string Last_Name { get; set; }


        [Required(ErrorMessage = "Please Enter UserTypeName")]
        [StringLength(100)]
        public string UserTypeName { get; set; }

        [RegularExpression(@"^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", ErrorMessage = "Enter Valid Email")]
        [Required(ErrorMessage = "Please Enter Email")]
        public string Email { get; set; }

        [Required]
        [StringLength(50)]
        public string Password { get; set; }



        [Required(ErrorMessage = "Please Enter Gender")]
        [StringLength(100)]
        public string Gender { get; set; }


        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }

        // [RegularExpression(@"^[+]?([0-9]{1,2})+\-([0-9]{10})", ErrorMessage = "Enter Valid Phone No eg(+91-1234578596)")]
        public string MobileNo { get; set; }

         public int PinCode { get; set; }

        [Required(ErrorMessage = "Please Enter Address")]
        [StringLength(500)]

        public string Address { get; set; }

        public IFormFile Photo { get; set; }

       


    }

    //public class UserUpdateModel : UserInsertModel
    //{
    //    [Required(ErrorMessage = "Id is neccessory for updation")]
    //    public Guid Id { get; set; }

    //}
    public class LoginModel
    {

        [Required(ErrorMessage = "Please Enter UserName")]
        [StringLength(100)]
        public string UserName { get; set; }

        [Required]
        [StringLength(50)]
        public string Password { get; set; }
    }
}
