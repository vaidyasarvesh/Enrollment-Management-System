﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.ViewModels
{
    public  class TeacherViewModel
    {
        public Guid Id { get; set; }
        public String Teacher_Name { get; set; }
    }
    public class TeacherInsertModel
    {
        [Required(ErrorMessage = "Teacher Name is required")]
        [StringLength(10)]
        public String Teacher_Name { get; set; }
    }
    public class TeacherUpdateModel : TeacherInsertModel
    {
        [Required(ErrorMessage = "Id is neccessory for updation")]
        public Guid Id { get; set; }

    }
}
