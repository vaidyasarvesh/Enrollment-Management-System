﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public  interface IResultService
    {
        Task<ICollection<ResultViewModel>> GetAll();
        Task<ResultViewModel> Get(Guid Id);
       
        Task<bool> Insert(ResultInsertModel resultInsertModel);
        Task<bool> Update(ResultUpdateModel resultUpdateModel);
        Task<bool> Delete(Guid Id);
        

    }
}
