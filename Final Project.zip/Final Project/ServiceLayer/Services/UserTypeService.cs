﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public class UserTypeService : IUserTypeService
    {
        #region ===Property===

        private readonly IRepository<UserType> _userType;

        #endregion

        #region ===Constructor===

        public UserTypeService(IRepository<UserType> userType)
        {
            _userType = userType;
        }

        #endregion

        public async Task<bool> Delete(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                UserType userType = await _userType.Get(Id)
;
                if (userType != null)
                {
                    var result = _userType.Delete(userType);
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public Task<UserType> Find(Expression<Func<UserType, bool>> match)
        {
            return _userType.Find(match);
        }

        public async Task<UserTypeModel> Get(Guid Id)
        {
            var result = await _userType.Get(Id)
;
            if (result == null)
                return null;
            else
            {
                UserTypeModel userTypeViewModel = new()
                {
                    Id = result.Id,
                    UserTypeName = result.UserTypeName
                };
                return userTypeViewModel;
            }
        }

        public async Task<ICollection<UserTypeModel>> GetAll()
        {
            ICollection<UserTypeModel> userTypeViewModels = new List<UserTypeModel>();
            ICollection<UserType> userTypes = await _userType.GetAll();
            foreach (UserType userType in userTypes)
            {
                UserTypeModel userTypeView = new()
                {
                    Id = userType.Id,
                    UserTypeName = userType.UserTypeName
                };
                userTypeViewModels.Add(userTypeView);
            }
            return userTypeViewModels;
        }

       

        public Task<bool> Insert(UserTypeInsertModel userInsertModel)
        {
            UserType userType = new()
            {
                UserTypeName = userInsertModel.UserTypeName

            };
            return _userType.Insert(userType);
        }

        public async Task<bool> Update(UserTypeUpdateModel userUpdateModel)
        {
            UserType userType = await _userType.Get(userUpdateModel.Id);
            if (userType != null)
            {
                userType.UserTypeName = userUpdateModel.UserTypeName;
                var result = await _userType.Update(userType);
                return result;
            }
            else
                return false;
        }
    }
}
