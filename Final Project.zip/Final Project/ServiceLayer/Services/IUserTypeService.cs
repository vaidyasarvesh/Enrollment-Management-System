﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public  interface IUserTypeService
    {
        Task<ICollection<UserTypeModel>> GetAll();
        Task<UserTypeModel> Get(Guid Id);
       
        Task<bool> Insert(UserTypeInsertModel userInsertModel);
        Task<bool> Update(UserTypeUpdateModel userUpdateModel);
        Task<bool> Delete(Guid Id);
        Task<UserType> Find(Expression<Func<UserType, bool>> match);
    }
}
