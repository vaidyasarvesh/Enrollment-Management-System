﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public class TeacherService : ITeacherService
    {
        #region ===Property===

       

        private readonly IRepository<TeacherTable> _teacherservice;


        #endregion

        #region ===Constructor===


        public TeacherService(IRepository<TeacherTable> teacherservice)
        {
            _teacherservice = teacherservice;   
        }
        #endregion

        public async Task<bool> Delete(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                TeacherTable teacher= await _teacherservice.Get(Id)
;
                if (teacher != null)
                {
                    var result = _teacherservice.Delete(teacher);
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        

        public async Task<TeacherViewModel> Get(Guid Id)
        {
            var result = await _teacherservice.Get(Id)
;
            if (result == null)
                return null;
            else
            {
                TeacherViewModel teacherViewModel = new()
                {
                    Id = result.Id,
                    Teacher_Name = result.Teacher_Name
                };
                return teacherViewModel;
            }
        }

        public async Task<ICollection<TeacherViewModel>> GetAll()
        {
            ICollection<TeacherViewModel> teacherViewModels = new List<TeacherViewModel>();
            ICollection<TeacherTable> teachers = await _teacherservice.GetAll();
            foreach (TeacherTable teacherType in teachers)
            {
                TeacherViewModel teacherView = new()
                {
                    Id = teacherType.Id,
                    Teacher_Name = teacherType.Teacher_Name
                };
                teacherViewModels.Add(teacherView);
            }
            return teacherViewModels;
        }

       

        public Task<bool> Insert(TeacherInsertModel teacherInsertModel)
        {
            TeacherTable teacher = new()
            {
                Teacher_Name = teacherInsertModel.Teacher_Name

            };
            return _teacherservice.Insert(teacher);
        }

        public async Task<bool> Update(TeacherUpdateModel teacherUpdateModel)
        {
            TeacherTable teacher= await _teacherservice.Get(teacherUpdateModel.Id);
            if (teacher != null)
            {
                teacher.Teacher_Name = teacherUpdateModel.Teacher_Name;
                var result = await _teacherservice.Update(teacher);
                return result;
            }
            else
                return false;
        }
    }
}
