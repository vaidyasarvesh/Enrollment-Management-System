﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public  class CourseService:ICourseService
    {
        private readonly IRepository<Course> _course;

        public CourseService(IRepository<Course> course)
        {
            _course = course;   
        }

        public async Task<bool> Delete(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                Course course = await _course.Get(Id)
;
                if (course != null)
                {
                    var result = _course.Delete(course);
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        

        public async Task<CourseViewModel> Get(Guid Id)
        {
            var result = await _course.Get(Id)
;
            if (result == null)
                return null;
            else
            {
                CourseViewModel courseViewModel = new()
                {
                    Id = result.Id,
                    Course_Name = result.Course_Name,
                    Course_Fees = result.Course_Fees,
                    Course_Description = result.Course_Description, 
                };
                return courseViewModel;
            }
        }

        public async Task<ICollection<CourseViewModel>> GetAll()
        {
            ICollection<CourseViewModel> courseViewModel = new List<CourseViewModel>();
            ICollection<Course> course = await _course.GetAll();
            foreach (Course coursetype in course)
            {
                CourseViewModel courseView = new()
                {
                    Id = coursetype.Id,
                    Course_Name = coursetype.Course_Name,
                    Course_Fees = coursetype.Course_Fees,
                    Course_Description = coursetype.Course_Description
                   
                };
                courseViewModel.Add(courseView);
            }
            return courseViewModel;
        }

        

        public   Task<bool> Insert(CourseInsertModel courseInsertModel)
        {
            Course course = new()
            {
                Course_Name = courseInsertModel.Course_Name,
                Course_Fees = courseInsertModel.Course_Fees,
                Course_Description = courseInsertModel.Course_Description
            };
            return _course.Insert(course);
        }

        public async Task<bool> Update(CourseUpdateModel courseUpdateModel)
        {
            Course course = await _course.Get(courseUpdateModel.Id);
            if (course != null)
            {
                course.Id = courseUpdateModel.Id;
                course.Course_Name = courseUpdateModel.Course_Name;
                course.Course_Fees = courseUpdateModel.Course_Fees;
                course.Course_Description = courseUpdateModel.Course_Description;
                var result = await _course.Update(course);
                return result;
            }
            else
                return false;
        }
        //private readonly IUserTypeService _userTypeService;
    }
}
