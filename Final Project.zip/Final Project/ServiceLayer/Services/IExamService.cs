﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public  interface IExamService
    {
        Task<ICollection<ExamViewModel>> GetAll();
        Task<ExamViewModel> Get(Guid Id);
       
        Task<bool> Insert(ExamInsertModel examInsertModel);
        Task<bool> Update(ExamUpdateModel examUpdateModel);
        Task<bool> Delete(Guid Id);
        
    }
}
