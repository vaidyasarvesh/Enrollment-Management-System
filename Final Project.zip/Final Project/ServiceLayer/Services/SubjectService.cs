﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public class SubjectService : ISubjectService
    {
        #region ===Property===

        private readonly IRepository<Subject> _subject;

        #endregion

        #region ===Constructor===

        public SubjectService(IRepository<Subject> subject)
        {
            _subject = subject;
        }

        #endregion


        public async Task<ICollection<SubjectViewModel>> GetAll()
        {
            ICollection<SubjectViewModel> subjectViewModels = new List<SubjectViewModel>();
            ICollection<Subject> subjects = await _subject.GetAll();
            foreach (Subject subject in subjects)
            {
                SubjectViewModel subjectView = new()
                {
                    Id = subject.Id,
                    Subject_Name = subject.Subject_Name
                };
                subjectViewModels.Add(subjectView);
            }
            return subjectViewModels;
        }

        

        public async Task<SubjectViewModel> Get(Guid Id)
        {
            var result = await _subject.Get(Id)
 ;
            if (result == null)
                return null;
            else
            {
                SubjectViewModel subjectViewModel = new()
                {
                    Id = result.Id,
                    Subject_Name = result.Subject_Name
                };
                return subjectViewModel;
            }
        }



        



        public Task<bool> Insert(SubjectInsertModel subjectInsertModel)
        {
            Subject subject = new()
            {
                Subject_Name = subjectInsertModel.Subject_Name

            };
            return _subject.Insert(subject);
        }

        public async Task<bool> Update(SubjectUpdateModel subjectUpdateModel)
        {
            Subject subject = await _subject.Get(subjectUpdateModel.Id);
            if (subject != null)
            {
                subject.Subject_Name = subjectUpdateModel.Subject_Name;
                var result = await _subject.Update(subject);
                return result;
            }
            else
                return false;
        }

        public async Task<bool> Delete(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                Subject subject = await _subject.Get(Id)
;
                if (subject != null)
                {
                    var result = _subject.Delete(subject);
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }


    }

} 

      
