﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public  interface IStudentService
    {
        Task<ICollection<StudentViewModel>> GetAll();
        Task<StudentViewModel> Get(Guid Id);
        
        Task<bool> Insert(StudentInsertModel studentInsertModel);
        Task<bool> Update(StudentUpdateModel studentUpdateModel);
        Task<bool> Delete(Guid Id);
       
    }
}
