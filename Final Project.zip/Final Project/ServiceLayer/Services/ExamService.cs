﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public class ExamService : IExamService
    {
        #region ===Property===

        private readonly IRepository<Exam> _exam;

        #endregion

        #region ===Constructor===

        public ExamService(IRepository<Exam> exam)
        {
            _exam = exam;
        }

        #endregion
        public async Task<bool> Delete(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                Exam exam = await _exam.Get(Id)
;
                if (exam != null)
                {
                    var result = _exam.Delete(exam);
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

       
        public async  Task<ExamViewModel> Get(Guid Id)
        {
            var result = await _exam.Get(Id);

            if (result == null)
                return null;
            else
            {
                ExamViewModel examViewModel = new()
                {
                    Id = result.Id,
                    Exam_Date = result.Exam_Date
                };
                return examViewModel;
            }
        }

        public async Task<ICollection<ExamViewModel>> GetAll()
        {
            ICollection<ExamViewModel> examViewModels = new List<ExamViewModel>();
            ICollection<Exam> exam = await _exam.GetAll();
            foreach (Exam examType in exam)
            {
                ExamViewModel examView = new()
                {
                    Id = examType.Id,
                    Exam_Date = examType.Exam_Date
                };
                examViewModels.Add(examView);
            }
            return examViewModels;
        }

       

        public  Task<bool> Insert(ExamInsertModel examInsertModel)
        {
            Exam exam = new()
            {
                
                Exam_Date = examInsertModel.Exam_Date

            };
            return _exam.Insert(exam);
        }

        public async Task<bool> Update(ExamUpdateModel examUpdateModel)
        {
            Exam exam = await _exam.Get(examUpdateModel.Id);
            if (exam != null)
            {
                exam.Exam_Date = examUpdateModel.Exam_Date;
                var result = await _exam.Update(exam);
                return result;
            }
            else
                return false;
        }
    }
}
