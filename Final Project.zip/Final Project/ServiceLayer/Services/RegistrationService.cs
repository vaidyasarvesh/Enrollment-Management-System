﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Repository.Repository;
using Services.common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public  class RegistrationService : IRegistrationService
    {
        private readonly IRepository<Registration> _registration;
        private readonly IUserTypeService _userTypeService;

        public RegistrationService(IRepository<Registration> registration, IUserTypeService userTypeService)
        {
            _registration = registration;
            _userTypeService = userTypeService;
        }

        public Task<Registration> Find(Expression<Func<Registration, bool>> match)
        {
            return _registration.Find(match);
        }

        public async Task<bool> Insert(UserInsertModel studentInsertModel, string photo)
        {
            var usertype = await _userTypeService.Find(x => x.UserTypeName == "Student");
            if (usertype != null)
            {
                Registration student = new()
                {
                    UserID = studentInsertModel.UserID,
                    First_Name = studentInsertModel.First_Name,
                    Last_Name = studentInsertModel.Last_Name,
                    UserTypeName = studentInsertModel.UserTypeName,
                    Email = studentInsertModel.Email,
                    Password = Encryptor.EncryptString(studentInsertModel.Password),
                    Gender = studentInsertModel.Gender,
                    DOB = studentInsertModel.DOB,
                    MobileNo = studentInsertModel.MobileNo,
                    PinCode = studentInsertModel.PinCode,
                    Address = studentInsertModel.Address,
                    Photo = photo
                };
                var result = await _registration.Insert(student);
                return result;
            }
            else
                return false;
        }
    }
}
