﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public class StudentService : IStudentService
    {

        #region ===Property===
        private readonly IRepository<Students> _student;
        #endregion

        #region ===Constructor===

        public StudentService(IRepository<Students>student)
        {
            _student = student;
        }
        #endregion


        public async Task<bool> Delete(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                Students student = await _student.Get(Id)
;
                if (student != null)
                {
                    var result = _student.Delete(student);
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

      

        public async Task<StudentViewModel> Get(Guid Id)
        {
            var result = await _student.Get(Id)
;
            if (result == null)
                return null;
            else
            {
                StudentViewModel studentviewmodel = new()
                {
                    Id = result.Id,
                    Student_FirstName = result.Student_FirstName,
                    Student_LastName = result.Student_LastName,
                    Student_DOB = result.Student_DOB,
                    StudentCourse_Name = result.StudentCourse_Name,
                };
                return studentviewmodel;
            }
        }

        public async Task<ICollection<StudentViewModel>> GetAll()
        {
            ICollection<StudentViewModel> userTypeViewModels = new List<StudentViewModel>();
            ICollection<Students> student = await _student.GetAll();
            foreach (Students students in student)
            {
                StudentViewModel studentview = new()
                {
                    Id = students.Id,
                    Student_FirstName = students.Student_FirstName,
                    Student_LastName = students.Student_LastName,
                    Student_DOB = students.Student_DOB,
                    StudentCourse_Name = students.StudentCourse_Name,

                };
                userTypeViewModels.Add(studentview);
            }
            return userTypeViewModels;
        }

       
        public Task<bool> Insert(StudentInsertModel studentInsertModel)
        {
           Students student = new()
            {
              
               Student_FirstName = studentInsertModel.Student_FirstName,
                Student_LastName=studentInsertModel.Student_LastName,
               Student_DOB = studentInsertModel.Student_DOB,
               StudentCourse_Name =studentInsertModel.StudentCourse_Name
             

            };
            return _student.Insert(student);
        }

        public async Task<bool> Update(StudentUpdateModel studentUpdateModel)
        {
            Students student = await _student.Get(studentUpdateModel.Id);
            if (student != null)
            {
                student.Student_FirstName = studentUpdateModel.Student_FirstName;
                student.Student_LastName = studentUpdateModel.Student_LastName;
                student.Student_DOB = studentUpdateModel.Student_DOB;
                student.StudentCourse_Name = studentUpdateModel.StudentCourse_Name;
                var result = await _student.Update(student);
                return result;
            }
            else
                return false;
        }
    }
}
