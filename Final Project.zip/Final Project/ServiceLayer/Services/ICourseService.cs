﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public interface ICourseService
    {    

        Task<ICollection<CourseViewModel>> GetAll();
        Task<CourseViewModel> Get(Guid Id);       
        Task<bool> Insert(CourseInsertModel courseInsertModel);
        Task<bool> Update(CourseUpdateModel userUpdateModel);
        Task<bool> Delete(Guid Id);
       
        
    }
}
