﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public  interface ISubjectService
    {
        Task<ICollection<SubjectViewModel>> GetAll();
        Task<SubjectViewModel> Get(Guid Id);
        
        Task<bool> Insert(SubjectInsertModel subjectInsertModel);
        Task<bool> Update(SubjectUpdateModel subjectUpdateModel);
        Task<bool> Delete(Guid Id);
        

    }
}
