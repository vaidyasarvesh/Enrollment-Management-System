﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Services
{
    public class ResultService : IResultService
    {
        #region ===Property===
        private readonly IRepository<ResultTable> _results;
        #endregion

        #region ===Constructor===

        public ResultService(IRepository<ResultTable> result)
        {
            _results = result;
        }

        #endregion
        public  async Task<bool> Delete(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                ResultTable resulttable= await _results.Get(Id)
;
                if (resulttable != null)
                {
                    var result = _results.Delete(resulttable);
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

       

        public async Task<ResultViewModel> Get(Guid Id)
        {
            var result = await _results.Get(Id);
 
            if (result == null)
                return null;
            else
            {
                ResultViewModel resultViewModel = new()
                {
                    Id = result.Id,
                    Student_Result = result.Student_Result
                };
                return resultViewModel;
            }
        }

        public async Task<ICollection<ResultViewModel>> GetAll()
        {
            ICollection<ResultViewModel> teacherViewModels = new List<ResultViewModel>();
            ICollection<ResultTable> results = await _results.GetAll();
            foreach (ResultTable resulttable in results)
            {
                ResultViewModel userTypeView = new()
                {
                    Id = resulttable.Id,
                    Student_Result = resulttable.Student_Result
                };
                teacherViewModels.Add(userTypeView);
            }
            return teacherViewModels;
        }

       

        public Task<bool> Insert(ResultInsertModel resultInsertModel)
        {
            ResultTable result= new()
            {
                Student_Result = resultInsertModel.Student_Result

            };
            return _results.Insert(result);
        }

        public async Task<bool> Update(ResultUpdateModel resultUpdateModel)
        {
            ResultTable resulttable= await _results.Get(resultUpdateModel.Id);
            if (resulttable != null)
            {
                resulttable.Student_Result = resultUpdateModel.Student_Result;
                var result = await _results.Update(resulttable);
                return result;
            }
            else
                return false;
        }
    }
}
