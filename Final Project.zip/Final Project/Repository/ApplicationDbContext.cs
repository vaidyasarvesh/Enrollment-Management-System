﻿using DomainLayer.Mapper;
using DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace Repository
{
    public class ApplicationDbContext  : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options) { }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new RegistrationMapper());
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new StudentMapper());
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new CourseMapper());
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new SubjectMapper());
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new ExamMapper());
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new ResultTableMapper());
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new TeacherAndSubjectJunctionMapper());
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new CoursesAndSubjectsJunctionMapper());
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new TeacherMapper());
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new UserTypeMapper());
            base.OnModelCreating(modelBuilder);           

        }

    }
}
