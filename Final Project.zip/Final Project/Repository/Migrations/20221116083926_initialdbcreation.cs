﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Repository.Migrations
{
    public partial class initialdbcreation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Course",
                columns: table => new
                {
                    CourseID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Course_Name = table.Column<string>(type: "Nvarchar(30)", nullable: false),
                    Course_Fees = table.Column<decimal>(type: "Decimal", nullable: false),
                    Course_Description = table.Column<string>(type: "Nvarchar(30)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_CourseID", x => x.CourseID);
                });

            migrationBuilder.CreateTable(
                name: "Subject",
                columns: table => new
                {
                    SubjectID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Subject_Name = table.Column<string>(type: "Nvarchar(150)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_SubjectID", x => x.SubjectID);
                });

            migrationBuilder.CreateTable(
                name: "TeacherTable",
                columns: table => new
                {
                    TeacherID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Teacher_Name = table.Column<string>(type: "Nvarchar(20)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_TeacherID", x => x.TeacherID);
                });

            migrationBuilder.CreateTable(
                name: "UserType",
                columns: table => new
                {
                    UserTypeID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserTypeName = table.Column<string>(type: "Nvarchar(10)", maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("Pk_UserTypeID", x => x.UserTypeID);
                });

            migrationBuilder.CreateTable(
                name: "CoursesAndSubjectJunction",
                columns: table => new
                {
                    CoursesJunID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SubjectJunID = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CoursesAndSubjectJunction", x => new { x.CoursesJunID, x.SubjectJunID });
                    table.ForeignKey(
                        name: "FK_CoursesAndSubjectJunction_Course_CoursesJunID",
                        column: x => x.CoursesJunID,
                        principalTable: "Course",
                        principalColumn: "CourseID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CoursesAndSubjectJunction_Subject_SubjectJunID",
                        column: x => x.SubjectJunID,
                        principalTable: "Subject",
                        principalColumn: "SubjectID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TeacherAndSubjectJunction",
                columns: table => new
                {
                    TeacherJunID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SubjectJunID = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TeacherAndSubjectJunction", x => new { x.TeacherJunID, x.SubjectJunID });
                    table.ForeignKey(
                        name: "FK_TeacherAndSubjectJunction_Subject_SubjectJunID",
                        column: x => x.SubjectJunID,
                        principalTable: "Subject",
                        principalColumn: "SubjectID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TeacherAndSubjectJunction_TeacherTable_TeacherJunID",
                        column: x => x.TeacherJunID,
                        principalTable: "TeacherTable",
                        principalColumn: "TeacherID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Registration",
                columns: table => new
                {
                    RegistrationID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserID = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    FirstName = table.Column<string>(type: "Nvarchar(100)", maxLength: 100, nullable: false),
                    LastName = table.Column<string>(type: "Nvarchar(100)", maxLength: 100, nullable: false),
                    UserTypeName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "Nvarchar(100)", nullable: false),
                    Password = table.Column<string>(type: "Nvarchar(50)", maxLength: 50, nullable: false),
                    Gender = table.Column<string>(type: "Nvarchar(10)", nullable: false),
                    DOB = table.Column<DateTime>(type: "DateTime", nullable: false),
                    MobileNo = table.Column<string>(type: "Nvarchar(15)", nullable: false),
                    PinCode = table.Column<int>(type: "int", nullable: false),
                    Address = table.Column<string>(type: "Nvarchar(100)", nullable: false),
                    Photo = table.Column<string>(type: "Nvarchar(200)", nullable: false),
                    UserTypeID = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("Pk_RegistrationID", x => x.RegistrationID);
                    table.ForeignKey(
                        name: "FK_Registration_UserType_UserTypeID",
                        column: x => x.UserTypeID,
                        principalTable: "UserType",
                        principalColumn: "UserTypeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    StudentID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RegistrationID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Student_FirstName = table.Column<string>(type: "Nvarchar(50)", nullable: false),
                    Student_LastName = table.Column<string>(type: "Nvarchar(50)", nullable: false),
                    Student_DOB = table.Column<DateTime>(type: "DateTime", nullable: false),
                    StudentCourse_Name = table.Column<string>(type: "Nvarchar(50)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_StudentID", x => x.StudentID);
                    table.ForeignKey(
                        name: "FK_Students_Registration_RegistrationID",
                        column: x => x.RegistrationID,
                        principalTable: "Registration",
                        principalColumn: "RegistrationID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Exam",
                columns: table => new
                {
                    ExamID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Exam_Date = table.Column<DateTime>(type: "DateTime", nullable: false),
                    StudentID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CourseID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SubjectID = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ExamID", x => x.ExamID);
                    table.ForeignKey(
                        name: "FK_Exam_Course_CourseID",
                        column: x => x.CourseID,
                        principalTable: "Course",
                        principalColumn: "CourseID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Exam_Students_StudentID",
                        column: x => x.StudentID,
                        principalTable: "Students",
                        principalColumn: "StudentID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Exam_Subject_SubjectID",
                        column: x => x.SubjectID,
                        principalTable: "Subject",
                        principalColumn: "SubjectID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ResultTable",
                columns: table => new
                {
                    ResultID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Student_Result = table.Column<string>(type: "Nvarchar(20)", nullable: true),
                    ExamID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    StudentID = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_ResultID", x => x.ResultID);
                    table.ForeignKey(
                        name: "FK_ResultTable_Exam_ExamID",
                        column: x => x.ExamID,
                        principalTable: "Exam",
                        principalColumn: "ExamID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ResultTable_Students_StudentID",
                        column: x => x.StudentID,
                        principalTable: "Students",
                        principalColumn: "StudentID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CoursesAndSubjectJunction_SubjectJunID",
                table: "CoursesAndSubjectJunction",
                column: "SubjectJunID");

            migrationBuilder.CreateIndex(
                name: "IX_Exam_CourseID",
                table: "Exam",
                column: "CourseID");

            migrationBuilder.CreateIndex(
                name: "IX_Exam_StudentID",
                table: "Exam",
                column: "StudentID");

            migrationBuilder.CreateIndex(
                name: "IX_Exam_SubjectID",
                table: "Exam",
                column: "SubjectID");

            migrationBuilder.CreateIndex(
                name: "IX_Registration_UserTypeID",
                table: "Registration",
                column: "UserTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_ResultTable_ExamID",
                table: "ResultTable",
                column: "ExamID");

            migrationBuilder.CreateIndex(
                name: "IX_ResultTable_StudentID",
                table: "ResultTable",
                column: "StudentID");

            migrationBuilder.CreateIndex(
                name: "IX_Students_RegistrationID",
                table: "Students",
                column: "RegistrationID");

            migrationBuilder.CreateIndex(
                name: "IX_TeacherAndSubjectJunction_SubjectJunID",
                table: "TeacherAndSubjectJunction",
                column: "SubjectJunID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CoursesAndSubjectJunction");

            migrationBuilder.DropTable(
                name: "ResultTable");

            migrationBuilder.DropTable(
                name: "TeacherAndSubjectJunction");

            migrationBuilder.DropTable(
                name: "Exam");

            migrationBuilder.DropTable(
                name: "TeacherTable");

            migrationBuilder.DropTable(
                name: "Course");

            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "Subject");

            migrationBuilder.DropTable(
                name: "Registration");

            migrationBuilder.DropTable(
                name: "UserType");
        }
    }
}
