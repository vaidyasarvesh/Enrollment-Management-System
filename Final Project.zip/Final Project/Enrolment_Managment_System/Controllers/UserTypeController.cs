﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceLayer.Services;
using System;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Enrolment_Managment_System.Controllers
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UserTypeController : ControllerBase
    {
        #region ===Property===

        private readonly IUserTypeService _serviceUserType;

       

        #endregion

        #region ===Constructor===
        public UserTypeController(IUserTypeService serviceUserType)
        {
            _serviceUserType = serviceUserType;
        }
        #endregion


        // GET: api/<UserTypeController>
        [HttpGet("GetAllUserType")]
      
        public async Task<ActionResult<UserTypeModel>> GetAllUserType()
        {
            var result = await _serviceUserType.GetAll();

            if (result == null)
            {
                return BadRequest("No Records Found");
            }
            return Ok(result);
        }

        // GET api/<UserTypeController>/5
        [HttpGet("GetUserType")]
        public async Task<ActionResult<UserTypeModel>> GetUserType(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                var result = await _serviceUserType.Get(Id)
;
                if (result == null)
                {
                    return BadRequest("No Records Found");
                }
                return Ok(result);
            }
            else
            {
                return NotFound("Invalid UserType Id...");
            }
        }

        // POST api/<UserTypeController>
        [HttpPost("Insert")]
        public async Task<IActionResult> InsertUserType(UserTypeInsertModel userTypeInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _serviceUserType.Insert(userTypeInsertModel);
                if (result == true)
                    return Ok("UserType Inserted...");
                else
                    return BadRequest("UserType Is Not Inserted..");
            }
            else
            {
                return BadRequest("Invalid UserType Information..");
            }
        }

        // PUT api/<UserTypeController>/5
        [HttpPut("Update")]
        public async Task<IActionResult> UpdateUserType(UserTypeUpdateModel userTypeModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _serviceUserType.Update(userTypeModel);
                if (result == true)
                    return Ok(userTypeModel);
                else
                    return BadRequest("Something went wrong Try again later...");
            }
            else
                return BadRequest("Invalid UserType Information..");
        }

        // DELETE api/<UserTypeController>/5
        [HttpDelete("Delete")]
        public async Task<IActionResult> DeleteUserType(Guid Id)
        {
            var result = await _serviceUserType.Delete(Id)
;
            if (result == true)
                return Ok("UserType Deleted...");
            else
                return BadRequest("UserType is not deleted...");
        }
    }
}
