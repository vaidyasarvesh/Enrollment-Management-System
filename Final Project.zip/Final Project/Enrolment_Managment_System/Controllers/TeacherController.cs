﻿using DomainLayer.ViewModels;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Services;
using System;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Enrolment_Managment_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherController : ControllerBase
    {


        #region ===Property===

        private readonly ITeacherService _teacherservice;
        #endregion

        #region ===Constructor===

        public TeacherController(ITeacherService teacherservice)
        {
            _teacherservice = teacherservice;
        }

        #endregion
        // GET: api/<TeacherController>
        [HttpGet("GetAllTeacher")]
        public async Task<ActionResult<TeacherViewModel>> GetAllTeacher()
        {
            var result = await _teacherservice.GetAll();

            if (result == null)
            {
                return BadRequest("No Records Found");
            }
            return Ok(result);
        }

        // GET api/<TeacherController>/5
        [HttpGet("GetTeacher")]
        public async Task<ActionResult<TeacherViewModel>> GetTeacher(Guid Id)
        {

            if (Id != Guid.Empty)
            {
                var result = await _teacherservice.Get(Id)
;
                if (result == null)
                {
                    return BadRequest("No Records Found");
                }
                return Ok(result);
            }
            else
            {
                return NotFound("Invalid Teacher Id...");
            }
        }

        // POST api/<TeacherController>
        [HttpPost("InsertTeacher")]
        public async Task<IActionResult> InsertTeacher(TeacherInsertModel teacherInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _teacherservice.Insert(teacherInsertModel);
                if (result == true)
                    return Ok("Teacher Inserted...");
                else
                    return BadRequest("Teacher Is Not Inserted..");
            }
            else
            {
                return BadRequest("Invalid Teacher Information..");
            }
        }

        // PUT api/<TeacherController>/5
        [HttpPut("UpdateTeacher")]
        public async Task<IActionResult> UpdateTeacher(TeacherUpdateModel teacherUpdateModel)
        {

            if (ModelState.IsValid)
            {
                var result = await _teacherservice.Update(teacherUpdateModel);
                if (result == true)
                    return Ok(teacherUpdateModel);
                else
                    return BadRequest("Something went wrong Try again later...");
            }
            else
                return BadRequest("Invalid Teacher Information..");
        }

        // DELETE api/<TeacherController>/5
        [HttpDelete("DeleteTeacher")]
        public async Task<IActionResult> DeleteTeacher(Guid Id)
        {

            var result = await _teacherservice.Delete(Id)
;
            if (result == true)
                return Ok("Teacher Deleted...");
            else
                return BadRequest("Teacher is not deleted...");
        }
    }
}
