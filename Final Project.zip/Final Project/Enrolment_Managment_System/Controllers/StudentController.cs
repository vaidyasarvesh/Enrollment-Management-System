﻿using DomainLayer.ViewModels;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Services;
using System;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Enrolment_Managment_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {


        #region ===Property===

        private readonly IStudentService _studentservice;
        #endregion

        #region ===Constructor===

        public StudentController(IStudentService studentservice)
        {
            _studentservice = studentservice;
        }

        #endregion
      // GET: api/<StudentController>
        [HttpGet("GetAllStudent")]
        public async Task<ActionResult<StudentViewModel>> GetAllStudent()
        {
            var result = await _studentservice.GetAll();

            if (result == null)
            {
                return BadRequest("No Records Found");
            }
            return Ok(result);
        }

        // GET api/<StudentController>/5
        [HttpGet("GetStudent")]
        public async Task<ActionResult<StudentViewModel>> GetStudent(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                var result = await _studentservice.Get(Id);
                if (result == null)
                {
                    return BadRequest("No Records Found");
                }
                return Ok(result);
            }
            else
            {
                return NotFound("Invalid Student Id...");
            }
        }

        // POST api/<StudentController>
        [HttpPost("InsertStudent")]
        public async Task<IActionResult> InsertUserType(StudentInsertModel studentInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _studentservice.Insert(studentInsertModel);
                if (result == true)
                    return Ok("Student Inserted...");
                else
                    return BadRequest("Student Is Not Inserted..");
            }
            else
            {
                return BadRequest("Invalid Student Information..");
            }
        }

        // PUT api/<StudentController>/5
        [HttpPut("UpdateStudent")]
        public async Task<IActionResult> UpdateUserType(StudentUpdateModel studentUpdateModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _studentservice.Update(studentUpdateModel);
                if (result == true)
                    return Ok(studentUpdateModel);
                else
                    return BadRequest("Something went wrong Try again later...");
            }
            else
                return BadRequest("Invalid Student Information..");
        }

        // DELETE api/<StudentController>/5
        [HttpDelete("DeleteStudent")]
        public async Task<IActionResult> DeleteUserType(Guid Id)
        {
            var result = await _studentservice.Delete(Id)
;
            if (result == true)
                return Ok("Student Deleted...");
            else
                return BadRequest("Student is not deleted...");
        }
    }
}
