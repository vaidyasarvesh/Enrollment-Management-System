﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Enrolment_Managment_System.Middleware.Auth;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Services;
using Services.common;
using System;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Enrolment_Managment_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationContoller : ControllerBase
    {

        #region ===Property===


        
        private readonly IRegistrationService _studentservice;
        private readonly IJWTAuthManager _authManager;
        private readonly IWebHostEnvironment _environment;
        private readonly IServices<UserType> _services;

        #endregion

        public RegistrationContoller( IRegistrationService studentService, IServices<UserType> service, IJWTAuthManager authManager, IWebHostEnvironment environment)
        {
           
            _studentservice= studentService;           
            _authManager = authManager;
            _environment = environment;
            _services = service;

        }


        // GET: api/<RegistrationContoller>
        [HttpPost("LoginUser")]
        public async Task<IActionResult> UserLogin(LoginModel Loginuser)
        {
            Response<string> response = new();
            if(ModelState.IsValid)
            {
                var user = await _studentservice.Find(x => x.First_Name == Loginuser.UserName && x.Password == Encryptor.EncryptString(Loginuser.Password));
                if (user == null)
                {
                    response.Message = "Invalid Username / Password..";
                    response.Status = (int)HttpStatusCode.NotFound;
                    return NotFound(response);
                }
                response.Message = _authManager.GenerateJWT(user);
                response.Status = (int)HttpStatusCode.OK;
                return Ok(response);
            }
            else
            {
                response.Message = "Invalid Login Information..";
                response.Status = (int)HttpStatusCode.NotAcceptable;
                return BadRequest(response);
            }
        }

        // GET api/<RegistrationContoller>/5
        [HttpPost(nameof(RegisterStudent))]
        public async Task<IActionResult> RegisterStudent([FromForm] UserInsertModel studentModel)
        {
            if (ModelState.IsValid)
            {
                var usertype = await _services.Find(x => x.UserTypeName == "Student");
                if (usertype != null)
                {
                    if (studentModel.Photo != null)
                    {
                        var CheckUser = await _studentservice.Find(x => x.UserID == studentModel.UserID);
                        if (CheckUser != null)
                        {
                            return BadRequest("User ID : " + studentModel.UserID + " already Exist");
                        }
                        else
                        {
                            var CheckUsername = await _studentservice.Find(x => x.First_Name == studentModel.First_Name);
                            if (CheckUsername != null)
                            {
                                return BadRequest(" UserName :" + studentModel.First_Name + " already Exist");
                            }
                        }
                        var photo = await UploadPhoto(studentModel.Photo, studentModel.First_Name, DateTime.Now.ToString("dd/MM/yyyy"));                        
                        if (string.IsNullOrEmpty(photo))
                        {
                            return BadRequest("Error While Uploading Student Profile Photo please Try again Later..");
                        }
                        var result = await _studentservice.Insert(studentModel, photo);
                        if (result == true)
                            return Ok("Student Registered Successfully");
                        else
                            return BadRequest("Error While Registering Student please Try again Later..");
                    }
                    else
                        return BadRequest("Upload Profile Photo..");
                }
                else
                    return BadRequest("Something Went Wrong please try again later");
            }
            else
                return BadRequest("Invalid Student Information..");
        }

        


        #region ==="Image Upload section"===
        private async Task<string> UploadPhoto(IFormFile file, string Id, string date)
        {
            string fileName;
            string contentPath = this._environment.ContentRootPath;
            var extension = "." + file.FileName.Split('.')[file.FileName.Split('.').Length - 1];
            if (extension == ".jpg" || extension == ".jpeg" || extension == ".png")
            {
                fileName = Id.ToLower() + "-" + date + extension;
                string outputFileName = Regex.Replace(fileName, @"[^0-9a-zA-Z.]+", "");
                var pathBuilt = Path.Combine(contentPath, "Images\\User");

                if (!Directory.Exists(pathBuilt))
                {
                    Directory.CreateDirectory(pathBuilt);
                }
                var path = Path.Combine(contentPath, "Images\\User", outputFileName);

                Console.WriteLine(path);

                using (var stream = new FileStream(path, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
                return outputFileName;
            }
            else
                return "";
        }
        #endregion "Image Upload section"
    }
}
