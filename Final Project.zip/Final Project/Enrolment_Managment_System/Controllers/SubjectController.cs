﻿using DomainLayer.ViewModels;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Services;
using System;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Enrolment_Managment_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubjectController : ControllerBase
    {

        #region ===Property===

        private readonly ISubjectService _subjectService;

        #endregion

        #region ===Constructor===

        public SubjectController(ISubjectService subjectService  )
        {
            _subjectService = subjectService;
        }

        #endregion


        // GET: api/<SubjectController>
        [HttpGet("GetAllSubject")]
        public async Task<ActionResult<SubjectViewModel>> GetAllSubject()
        {
            var result = await _subjectService.GetAll();

            if (result == null)
            {
                return BadRequest("No Records Found");
            }
            return Ok(result);
        }

        // GET api/<SubjectController>/5
        [HttpGet("GetSubject")]
        public async Task<ActionResult<SubjectViewModel>> GetSubject(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                var result = await _subjectService.Get(Id)
;
                if (result == null)
                {
                    return BadRequest("No Records Found");
                }
                return Ok(result);
            }
            else
            {
                return NotFound("Invalid Subject Id...");
            }
        }

        // POST api/<SubjectController>
        [HttpPost("InsertSubject")]
        public async Task<IActionResult> InsertSubject(SubjectInsertModel subjectInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _subjectService.Insert(subjectInsertModel);
                if (result == true)
                    return Ok("Subject Inserted...");
                else
                    return BadRequest("Subject Is Not Inserted..");
            }
            else
            {
                return BadRequest("Invalid Subject Information..");
            }
        }

        // PUT api/<SubjectController>/5
        [HttpPut("UpdateSubject")]
        public async Task<IActionResult> UpdateSubject(SubjectUpdateModel subjectUpdateModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _subjectService.Update(subjectUpdateModel);
                if (result == true)
                    return Ok(subjectUpdateModel);
                else
                    return BadRequest("Something went wrong Try again later...");
            }
            else
                return BadRequest("Invalid Subject Information..");
        }

        // DELETE api/<SubjectController>/5
        [HttpDelete("DeleteSubject")]
        public async Task<IActionResult> DeleteSubject(Guid Id)
        {
            var result = await _subjectService.Delete(Id)
;
            if (result == true)
                return Ok("Subject Deleted...");
            else
                return BadRequest("Subject is not deleted...");
        }
    }
}
