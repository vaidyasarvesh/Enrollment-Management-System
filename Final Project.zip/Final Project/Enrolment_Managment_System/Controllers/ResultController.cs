﻿using DomainLayer.ViewModels;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Services;
using System;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Enrolment_Managment_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResultController : ControllerBase
    {

        #region ===Property===
        private readonly IResultService  _resultservice;
        #endregion
        #region ===Constructor===

        public ResultController(IResultService resultservice)
        {
            _resultservice = resultservice;
        }

        #endregion

        // GET: api/<ResultController>
        [HttpGet("GetAllResult")]
        public async Task<ActionResult<ResultViewModel>> GetAllResult()
        {
            var result = await _resultservice.GetAll();

            if (result == null)
            {
                return BadRequest("No Records Found");
            }
            return Ok(result);
        }

        // GET api/<ResultController>/5
        [HttpGet("GetResult")]
        public async Task<ActionResult<ResultViewModel>> GetUserType(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                var result = await _resultservice.Get(Id)
;
                if (result == null)
                {
                    return BadRequest("No Records Found");
                }
                return Ok(result);
            }
            else
            {
                return NotFound("Invalid Result Id...");
            }
        }

        // POST api/<ResultController>
        [HttpPost("InsertResult")]
        public async Task<IActionResult> InsertResult(ResultInsertModel resultInsertModel)
        {

            if (ModelState.IsValid)
            {
                var result = await _resultservice.Insert(resultInsertModel);
                if (result == true)
                    return Ok("Result  Inserted...");
                else
                    return BadRequest("Result Is Not Inserted..");
            }
            else
            {
                return BadRequest("Invalid Result Information..");
            }
        }

        // PUT api/<ResultController>/5
        [HttpPut("UpdateResult")]
        public async Task<IActionResult> UpdateResult(ResultUpdateModel resultUpdateModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _resultservice.Update(resultUpdateModel);
                if (result == true)
                    return Ok(resultUpdateModel);
                else
                    return BadRequest("Something went wrong Try again later...");
            }
            else
                return BadRequest("Invalid Result Information..");
        }

        // DELETE api/<ResultController>/5
        [HttpDelete("DeleteResult")]
        public async Task<IActionResult> DeleteResult(Guid Id)
        {
            var result = await _resultservice.Delete(Id)
;
            if (result == true)
                return Ok("Result Deleted...");
            else
                return BadRequest("Result is not deleted...");
        }
    }
}
