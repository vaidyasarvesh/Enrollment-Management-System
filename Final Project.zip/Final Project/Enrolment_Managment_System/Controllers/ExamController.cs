﻿using DomainLayer.Models;
using DomainLayer.ViewModels;
using Enrolment_Managment_System.Middleware.Auth;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceLayer.Services;
using System;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Enrolment_Managment_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExamController : ControllerBase
    {
      
        private readonly IExamService _examService;              
        

        public ExamController(IExamService examservice)
        {
            _examService = examservice;
        }





        // GET: api/<ExamController>
        [HttpGet("GetAllExam")]
        public async Task<ActionResult<ExamViewModel>> GetAllExam()
        {
            var result = await _examService.GetAll();

            if (result == null)
            {
                return BadRequest("No Records Found");
            }
            return Ok(result);
        }

        // GET api/<ExamController>/5
        [HttpGet("GetExam")]
        public async Task<ActionResult<ExamViewModel>> GetExam(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                var result = await _examService.Get(Id)
;
                if (result == null)
                {
                    return BadRequest("No Records Found");
                }
                return Ok(result);
            }
            else
            {
                return NotFound("Invalid UserType Id...");
            }
        }

        // POST api/<ExamController>
        [HttpPost("InsertExam")]
        public async Task<IActionResult> InsertExam(ExamInsertModel examInsertModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _examService.Insert(examInsertModel);
                if (result == true)
                    return Ok("Exam Inserted...");
                else
                    return BadRequest("Exam Is Not Inserted..");
            }
            else
            {
                return BadRequest("Invalid Exam Information..");
            }
        }

        // PUT api/<ExamController>/5
        [HttpPut("UpdateExam")]
        public async Task<IActionResult> UpdateExam(ExamUpdateModel examUpdateModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _examService.Update(examUpdateModel);
                if (result == true)
                    return Ok(examUpdateModel);
                else
                    return BadRequest("Something went wrong Try again later...");
            }
            else
                return BadRequest("Invalid UserType Information..");
        }

        // DELETE api/<ExamController>/5
        [HttpDelete("DeleteExam")]
        public async Task<IActionResult> DeleteExam(Guid Id)
        {
            var result = await _examService.Delete(Id)
;
            if (result == true)
                return Ok("Exam Deleted...");
            else
                return BadRequest("Exam is not deleted...");

        }
    }
}
