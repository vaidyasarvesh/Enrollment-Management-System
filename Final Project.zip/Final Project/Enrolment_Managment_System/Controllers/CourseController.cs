﻿using DomainLayer.ViewModels;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Services;
using System;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Enrolment_Managment_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        #region ===Property===

        private readonly ICourseService _courseService;

        #endregion

        #region ===Constructor===

        public CourseController(ICourseService courseservice)
        {
            _courseService = courseservice;
        }

        #endregion


        // GET: api/<CourseController>
        [HttpGet("GetAllCourse")] 
        public async Task<ActionResult<CourseViewModel>> GetAllCourse()
        {
            var result = await _courseService.GetAll();

            if (result == null)
            {
                return BadRequest("No Records Found");
            }
            return Ok(result);
        }

        // GET api/<CourseController>/5
        [HttpGet("GetCourse")]
        public async Task<ActionResult<CourseViewModel>> GetCourse(Guid Id)
        {
            if (Id != Guid.Empty)
            {
                var result = await _courseService.Get(Id)
;
                if (result == null)
                {
                    return BadRequest("No Records Found");
                }
                return Ok(result);
            }
            else
            {
                return NotFound("Invalid UserType Id...");
            }
        }

        // POST api/<CourseController>
        [HttpPost("InsertCourse")]
        public async Task<IActionResult> InsertCourse(CourseInsertModel courseInsertModel)
        {
            if(ModelState.IsValid)
            {
                var result=await _courseService.Insert(courseInsertModel);
                if (result == true)
                    return Ok("Course Inserted...");
                else
                    return BadRequest("Course  Is Not Inserted...");
            }
            else
            {
                return BadRequest("Invalid Course Information..");
            }

        }

        // PUT api/<CourseController>/5
        [HttpPut("UpdateCourse")]
        public async Task<IActionResult> UpdateCourse(CourseUpdateModel courseUpdateModel)
        {
            if (ModelState.IsValid)
            {
                var result = await _courseService.Update(courseUpdateModel);
                if (result == true)
                    return Ok(courseUpdateModel);
                else
                    return BadRequest("Something went wrong Try again later...");
            }
            else
                return BadRequest("Invalid Course Information..");
        }

        // DELETE api/<CourseController>/5
        [HttpDelete("DeleteCourse")]
        public async Task<IActionResult> DeleteCourse(Guid Id)
        {
            var result = await _courseService.Delete(Id);
            if (result == true)
                return Ok("Course Deleted...");
            else
                return BadRequest("Course is not deleted...");
        }
    }
}
