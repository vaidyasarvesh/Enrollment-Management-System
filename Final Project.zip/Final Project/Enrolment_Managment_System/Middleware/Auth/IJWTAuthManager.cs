﻿using DomainLayer.Models;

namespace Enrolment_Managment_System.Middleware.Auth
{
    public interface IJWTAuthManager
    {
        string GenerateJWT(Registration registration);
    }
}
